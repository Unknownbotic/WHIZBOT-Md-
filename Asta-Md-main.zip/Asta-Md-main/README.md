## ASTA-MD WHATSAPP BOT

***

### ᴀsᴛᴀ ᴍᴅ ᴜᴘᴅᴀᴛᴇ 2.0.0 ᴘᴀᴛᴄʜ
##### Get Latest Info
[Channel](https://whatsapp.com/channel/0029VaPGt3QEwEjpBXT4Rv0z)

### SETUP
#### Star Asta Md & Fork
<center>
<a href="https://github.com/Astropeda/Asta-Md/fork"><img title="ASTA-MD" src="https://img.shields.io/badge/FORK ASTA-MD-h?color=black&style=for-the-badge&logo=stackshare"></a>  <a href="https://asta-code-app-9b7d929f3f62.herokuapp.com/qr"><img title="SCAN QR " src="https://img.shields.io/badge/SCAN QR -h?color=black&style=for-the-badge&logo=msi"></a> <a href="https://asta-code-app-9b7d929f3f62.herokuapp.com/pair"><img title="PARING CODE" src="https://img.shields.io/badge/PARING CODE -h?color=black&style=for-the-badge&logo=msi"></a>

### ASTA Deploy Methods


-------

#### Deploy To Platforms

<a href="https://heroku.com/deploy?template=https://github.com/Astropeda/Asta-Md"><img title="ASTA-MD Deploy Heroku" src="https://img.shields.io/badge/DEPLOY HEROKU-h?color=black&style=for-the-badge&logo=heroku"></a> 
 <a href="https://railway.app/project/"><img title="INRL-MD Deploy Railway" src="https://img.shields.io/badge/DEPLOY RAILWAY-h?color=black&style=for-the-badge&logo=Railway"></a>  <a href="https://app.koyeb.com/apps/deploy?type=git&repository=github.com/Astropeda/Asta-Md&branch=main&env[SESSION_ID]&env[OWNER_NUMBER]=2348039607375&env[MONGODB_URI]&&env[OWNER_NAME]=Asta&env[KOYEB_API]&env[PREFIX]=.&env[WAPRESENCE]&env[AUTO_READ_STATUS]=false&env[DISABLE_PM]=false&env[PACK_AUTHER]=whatsapp+bot&env[PACK_NAME]=Asta+MD&env[STYLE]=0&env[MODE]=private&env[READ_MESSAGE]=false&env[THEME]=Whatsappbot&env[WARN_COUNT]=3&env[BLOCK_JID]=null&env[TIME_ZONE]=Africa/Lagos&name=asta-md&env[KOYEB_NAME]=asta-md&env[SUDO]=null&env[THUMB_IMAGE]=https://imgur.com/dMwGOUP.jpg"><img title="ASTA-MD Deploy Koyeb" src="https://img.shields.io/badge/DEPLOY KOYEB-h?color=black&style=for-the-badge&logo=koyeb"></a>  <a href="https://replit.com/github/Astropeda/Asta-Md"><img title="INRL-MD Deploy Replit" src="https://img.shields.io/badge/DEPLOY REPLIT-h?color=black&style=for-the-badge&logo=Replit"></a>  <a href="https://github.com/codespaces/new?skip_quickstart=true&machine=standardLinux32gb&repo=763349202&ref=main&geo=UsWest"><img title="ASTA-MD Deploy Codespaces" src="https://img.shields.io/badge/DEPLOY CODESPACES-h?color=black&style=for-the-badge&logo=github"></a>  <a href="https://glitch.com/"><img title="ASTA-MD Deploy Glitch" src="https://img.shields.io/badge/DEPLOY GLITCH-h?color=black&style=for-the-badge&logo=glitch"></a>

 ### Support Channel

<a href="https://whatsapp.com/channel/0029VaPGt3QEwEjpBXT4Rv0z"><img title="ASTA-MD Deploy Glitch" src="https://img.shields.io/badge/WHATSAPP CHANNEL-h?color=black&style=for-the-badge&logo=whatsapp"></a>
